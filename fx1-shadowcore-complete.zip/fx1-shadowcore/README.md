# FX1 SHADOWCORE
Authorized-testing security operations platform. Next.js 14 (App Router) + TypeScript + Tailwind + Lucide.

    npm install && cp .env.example .env.local && npm run dev

- Every lookup/scan requires "I confirm this target is authorized". Admin (Fx1faucet@gmail.com) may skip the justification; others need 10+ chars.
- HIBP breach data: set `HIBP_API_KEY` in `.env.local` (never hardcode).
- Server guards: private/loopback targets blocked (SSRF), fixed port list, passive discovery only.
- Findings/history live in sessionStorage.
- Identity is self-asserted (no login). Add real authentication (e.g. NextAuth) and per-user rate limiting before any public deployment.
- UI primitives are shadcn-style Tailwind; run `npx shadcn@latest init` to swap in the full library.
