import dns from "dns/promises";
import net from "net";
export const ADMIN=(process.env.ADMIN_EMAIL||"Fx1faucet@gmail.com").toLowerCase();
export const isAdmin=(u?:string)=>!!u&&u.trim().toLowerCase()===ADMIN;
// NOTE: identity is self-asserted (no auth layer). Add real auth before exposing publicly.
export function gate(b:any){
  if(!b?.authorized) return "Authorization confirmation required: confirm this target is authorized.";
  if(!isAdmin(b.user)&&String(b.justification||"").trim().length<10) return "A short justification (10+ characters) is required for non-admin users.";
  return null;
}
export const bad=(m:string,s=400)=>Response.json({error:m},{status:s});
const priv=(ip:string)=>{
  if(net.isIPv6(ip)) return /^(::1|fc|fd|fe80|::ffff:(10|127|192\.168|172\.(1[6-9]|2\d|3[01])))/i.test(ip);
  const [a,b]=ip.split(".").map(Number);
  return a===10||a===127||a===0||(a===169&&b===254)||(a===172&&b>=16&&b<=31)||(a===192&&b===168)||(a===100&&b>=64&&b<=127);
};
// SSRF guard: only public hosts may be contacted
export async function publicHost(h:string){
  if(!/^[a-z0-9.\-:]+$/i.test(h)) throw new Error("Invalid host");
  const r=await dns.lookup(h,{all:true});
  if(!r.length||r.some(x=>priv(x.address))) throw new Error("Private, loopback and internal targets are blocked");
  return r[0].address;
}
