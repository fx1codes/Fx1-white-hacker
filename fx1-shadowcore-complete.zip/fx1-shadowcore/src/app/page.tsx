"use client";
import {useEffect,useMemo,useState} from "react";
import {Shield,LayoutDashboard,Target,Mail,Search,Network,Globe,ListChecks,FileText,KeyRound,Copy,Download,Loader2,Check,Crosshair,Printer} from "lucide-react";

type Sev="Critical"|"High"|"Medium"|"Low"|"Info";
type F={id:string;module:string;target:string;title:string;severity:Sev;detail:string;fix:string;eng:string;status:"Open"|"Remediated";ts:string};
type St={user:string;active:string;eng:{id:string;name:string;targets:string;ts:string}[];f:F[];jobs:{id:string;m:string;t:string;ts:string}[];mail:{r:string;risk:string;ts:string}[]};
const init:St={user:"",active:"",eng:[],f:[],jobs:[],mail:[]};
const uid=()=>Math.random().toString(36).slice(2,9);
const now=()=>new Date().toISOString().slice(0,16).replace("T"," ");
const ADMIN="fx1faucet@gmail.com";const isAdm=(u:string)=>u.trim().toLowerCase()===ADMIN;
const SO=["Critical","High","Medium","Low","Info"];
const SC:Record<string,string>={Critical:"bg-red-500/20 text-red-300 border-red-500/50",High:"bg-orange-500/15 text-orange-300 border-orange-500/40",Medium:"bg-yellow-500/15 text-yellow-300 border-yellow-500/40",Low:"bg-emerald-500/15 text-emerald-300 border-emerald-500/40",Info:"bg-blue-500/15 text-blue-300 border-blue-500/40"};
let tf=(m:string)=>{};const T=(m:string)=>tf(m);
const Badge=({v}:{v:string})=><span className={`px-1.5 py-0.5 rounded border text-[10px] font-semibold uppercase ${SC[v]||SC.Info}`}>{v}</span>;
const Card=({title,right,children,cls=""}:any)=><section className={`rounded-lg border border-blue-500/15 bg-[#0b1220] p-3 ${cls}`}>{title&&<div className="flex items-center justify-between mb-2"><h3 className="text-sm font-semibold text-blue-100">{title}</h3>{right}</div>}{children}</section>;
const inp="w-full rounded bg-[#070b14] border border-blue-500/20 px-2 py-1.5 text-sm outline-none focus:border-blue-400";
const btn="inline-flex items-center gap-1.5 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 px-3 py-1.5 text-sm font-medium text-white";
const ghost="inline-flex items-center gap-1.5 rounded border border-blue-500/30 hover:bg-blue-500/10 px-2.5 py-1.5 text-xs";
const dl=(n:string,t:string)=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([t]));a.download=n;a.click();T("Exported "+n)};
const cp=(t:string)=>navigator.clipboard.writeText(t).then(()=>T("Copied to clipboard"));
const Empty=({t}:{t:string})=><div className="text-center text-xs text-blue-300/50 border border-dashed border-blue-500/20 rounded py-8">{t}</div>;
const Err=({t}:{t:string})=><div className="rounded border border-red-500/40 bg-red-500/10 text-red-300 text-sm p-2">{t}</div>;

function useApi(){const [l,sl]=useState(false);const [e,se]=useState("");const [d,sd]=useState<any>(null);
  const run=async(path:string,body:any)=>{sl(true);se("");sd(null);try{const r=await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const j=await r.json();if(!r.ok)throw new Error(j.error||"Request failed");sd(j);return j}catch(x:any){se(x.message);T(x.message);return null}finally{sl(false)}};
  return {l,e,d,run}}

function Auth({admin,v,set}:any){return <div className="space-y-2 rounded border border-blue-500/20 p-2 bg-blue-500/5">
  <label className="flex gap-2 text-sm items-start"><input type="checkbox" className="mt-1" checked={v.ok} onChange={e=>set({...v,ok:e.target.checked})}/>I confirm this target is authorized</label>
  <input className={inp} placeholder={admin?"Justification (optional for admin)":"Justification (required, 10+ characters)"} value={v.j} onChange={e=>set({...v,j:e.target.value})}/></div>}

function Table({cols,rows}:{cols:[string,string][];rows:any[]}){const [k,sk]=useState("");const [asc,sa]=useState(true);
  const R=useMemo(()=>k?[...rows].sort((x,y)=>(k==="severity"?SO.indexOf(x[k])-SO.indexOf(y[k]):String(x[k])>String(y[k])?1:-1)*(asc?1:-1)):rows,[rows,k,asc]);
  return <div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="text-left text-blue-300/70">{cols.map(([c,l])=><th key={c} onClick={()=>{sa(k===c?!asc:true);sk(c)}} className="py-1.5 px-2 cursor-pointer select-none whitespace-nowrap">{l}{k===c?(asc?" ▲":" ▼"):""}</th>)}</tr></thead>
  <tbody>{R.map((r,i)=><tr key={i} className="border-t border-blue-500/10">{cols.map(([c])=><td key={c} className="py-1.5 px-2 align-top">{["severity","risk","confidence"].includes(c)?<Badge v={r[c]}/>:String(r[c]??"")}</td>)}</tr>)}</tbody></table></div>}

function Tool({cfg,s,add}:any){const [t,st]=useState("");const [a,sa]=useState({ok:false,j:""});const api=useApi();
  const go=async()=>{if(!t.trim())return T("Enter a target");const j=await api.run(cfg.path,{[cfg.key]:t.trim(),authorized:a.ok,justification:a.j,user:s.user});if(j){add(cfg.name,t.trim(),j.findings||[]);T(`${cfg.name}: ${j.rows.length} result(s)`)}};
  return <div className="grid lg:grid-cols-3 gap-3"><Card title={cfg.name}><div className="space-y-2"><p className="text-xs text-blue-300/60">{cfg.help}</p>
    <input className={inp} placeholder={cfg.ph} value={t} onChange={e=>st(e.target.value)} onKeyDown={e=>e.key==="Enter"&&go()}/>
    <Auth admin={isAdm(s.user)} v={a} set={sa}/><button className={btn} disabled={api.l} onClick={go}>{api.l?<Loader2 size={14} className="animate-spin"/>:<Crosshair size={14}/>}{api.l?"Running…":cfg.btn}</button></div></Card>
    <Card title="Results" cls="lg:col-span-2" right={api.d&&<button className={ghost} onClick={()=>cp(JSON.stringify(api.d,null,2))}><Copy size={12}/>Copy JSON</button>}>
      {api.l?<div className="py-8 text-center text-sm text-blue-300"><Loader2 className="animate-spin inline mr-2" size={16}/>Working…</div>:api.e?<Err t={api.e}/>:!api.d?<Empty t="No results yet. Confirm authorization and run."/>:
      api.d.rows.length===0?<Empty t="Nothing found for this target."/>:<div className="space-y-3">{api.d.ip&&<div className="text-xs">Resolved IP: <code>{api.d.ip}</code></div>}<Table cols={cfg.cols} rows={api.d.rows}/></div>}</Card></div>}

function EmailIntel({s,S,add}:any){const [e,se]=useState("");const [a,sa]=useState({ok:false,j:""});const api=useApi();const d=api.d;
  const go=async()=>{const j=await api.run("/api/email",{email:e,authorized:a.ok,justification:a.j,user:s.user});if(j){add("Email Intelligence",e,j.findings);const [u,dm]=e.split("@");S((p:St)=>({...p,mail:[{r:u[0]+"***@"+dm,risk:j.risk,ts:now()},...p.mail].slice(0,30)}));T("Lookup complete: "+j.risk+" risk")}};
  const AU=d?[["SPF",d.auth.spf],["DKIM",d.auth.dkim],["DMARC",d.auth.dmarc]]:[];
  return <div className="grid lg:grid-cols-3 gap-3"><div className="space-y-3"><Card title="Email Intelligence"><div className="space-y-2">
    <input className={inp} placeholder="user@example.com" value={e} onChange={x=>se(x.target.value)} onKeyDown={x=>x.key==="Enter"&&go()}/>
    <Auth admin={isAdm(s.user)} v={a} set={sa}/><button className={btn} disabled={api.l} onClick={go}>{api.l?<Loader2 size={14} className="animate-spin"/>:<Mail size={14}/>}Analyze email</button></div></Card>
    <Card title="Lookup history">{!s.mail.length?<Empty t="No lookups this session."/>:<Table cols={[["r","Address"],["risk","Risk"],["ts","Date"]]} rows={s.mail}/>}</Card></div>
    <div className="lg:col-span-2 space-y-3">{api.l?<Card><div className="py-10 text-center text-sm text-blue-300"><Loader2 className="animate-spin inline mr-2" size={16}/>Querying DNS and breach sources…</div></Card>:api.e?<Err t={api.e}/>:!d?<Card><Empty t="Enter an authorized address to see risk score, SPF/DKIM/DMARC, breach exposure and actions."/></Card>:<>
      <Card><div className="flex items-center justify-between flex-wrap gap-2"><div><div className="text-xs text-blue-300/60">Overall risk</div><div className="flex items-center gap-2 mt-1"><Badge v={d.risk}/><span className="text-2xl font-bold text-white">{d.score}<span className="text-xs text-blue-300/50">/100</span></span></div></div>
        <div className="text-xs space-y-0.5"><div>Email: <code>{d.email}</code></div><div>Domain: <code>{d.domain}</code> · MX records: {d.mx}</div></div>
        <button className={ghost} onClick={()=>cp(JSON.stringify(d,null,2))}><Copy size={12}/>Copy</button></div></Card>
      <div className="grid sm:grid-cols-3 gap-3">{AU.map(([n,x]:any)=><Card key={n} title={n} right={<Badge v={x.ok?"Low":"High"}/>}><p className="text-xs break-all text-blue-200/70">{x.ok?"Present — ":"Missing — "}{x.v}</p></Card>)}</div>
      <Card title="Breach exposure">{d.breach.status==="not_configured"?<p className="text-xs text-blue-300/70">HIBP not configured. Set <code>HIBP_API_KEY</code> in your environment to enable.</p>:d.breach.status==="error"?<Err t={d.breach.message}/>:d.breach.count===0?<p className="text-sm text-emerald-300">No known breaches.</p>:<p className="text-sm">{d.breach.count} breach(es): {d.breach.names.join(", ")}</p>}</Card>
      <Card title="Risk factors">{!d.findings.length?<Empty t="No risk factors detected."/>:<ul className="space-y-1.5">{d.findings.map((f:any,i:number)=><li key={i} className="flex gap-2 text-xs"><Badge v={f.severity}/><span><b className="text-blue-100">{f.title}</b> — {f.detail}</span></li>)}</ul>}</Card>
      <Card title="Recommended actions">{d.actions.length?<ul className="list-disc pl-4 text-xs space-y-1">{d.actions.map((x:string)=><li key={x}>{x}</li>)}</ul>:<p className="text-xs text-emerald-300">No action required.</p>}</Card></>}</div></div>}

function Scope({s,S}:any){const [n,sn]=useState("");const [t,st]=useState("");const [a,sa]=useState({ok:false,j:""});
  const go=()=>{if(!n.trim()||!t.trim())return T("Name and targets are required");if(!a.ok)return T("Authorization confirmation required");if(!isAdm(s.user)&&a.j.trim().length<10)return T("Justification required (10+ chars)");
    S((p:St)=>({...p,active:n.trim(),eng:[{id:uid(),name:n.trim(),targets:t.trim(),ts:now()},...p.eng]}));sn("");st("");sa({ok:false,j:""});T("Engagement created")};
  return <div className="grid lg:grid-cols-3 gap-3"><Card title="New engagement"><div className="space-y-2"><input className={inp} placeholder="Engagement name" value={n} onChange={e=>sn(e.target.value)}/>
    <textarea className={inp+" h-28"} placeholder={"Targets, one per line\nexample.com\n203.0.113.10\nsecurity@example.com"} value={t} onChange={e=>st(e.target.value)}/><Auth admin={isAdm(s.user)} v={a} set={sa}/><button className={btn} onClick={go}><Check size={14}/>Create engagement</button></div></Card>
    <Card title="Engagements" cls="lg:col-span-2">{!s.eng.length?<Empty t="No engagements yet. Create one to scope your testing."/>:<Table cols={[["name","Name"],["targets","Targets"],["ts","Created"]]} rows={s.eng.map((e:any)=>({...e,targets:e.targets.split("\n").join(", ")}))}/>}</Card></div>}

function Findings({s,S}:any){const [sv,ssv]=useState("");const [m,sm]=useState("");const [en,sen]=useState("");
  const L=s.f.filter((f:F)=>(!sv||f.severity===sv)&&(!m||f.module===m)&&(!en||f.eng===en));const mods=[...new Set(s.f.map((f:F)=>f.module))] as string[];const engs=[...new Set(s.f.map((f:F)=>f.eng))] as string[];
  const toggle=(id:string)=>{S((p:St)=>({...p,f:p.f.map(f=>f.id===id?{...f,status:f.status==="Open"?"Remediated":"Open"}:f)}));T("Status updated")};
  const csv=()=>"severity,module,target,title,status,fix\n"+L.map((f:F)=>[f.severity,f.module,f.target,f.title,f.status,f.fix].map(x=>`"${String(x).replace(/"/g,'""')}"`).join(",")).join("\n");
  const sel="rounded bg-[#070b14] border border-blue-500/20 px-2 py-1 text-xs";
  return <Card title={`Findings (${L.length})`} right={<div className="flex gap-1.5 flex-wrap"><button className={ghost} onClick={()=>dl("findings.json",JSON.stringify(L,null,2))}><Download size={12}/>JSON</button><button className={ghost} onClick={()=>dl("findings.csv",csv())}><Download size={12}/>CSV</button></div>}>
    <div className="flex gap-2 mb-3 flex-wrap"><select className={sel} value={sv} onChange={e=>ssv(e.target.value)}><option value="">All severities</option>{SO.map(x=><option key={x}>{x}</option>)}</select>
    <select className={sel} value={m} onChange={e=>sm(e.target.value)}><option value="">All modules</option>{mods.map(x=><option key={x}>{x}</option>)}</select>
    <select className={sel} value={en} onChange={e=>sen(e.target.value)}><option value="">All engagements</option>{engs.map(x=><option key={x}>{x}</option>)}</select></div>
    {!L.length?<Empty t="No findings. Run a module to populate this list."/>:<div className="space-y-1.5">{[...L].sort((a,b)=>SO.indexOf(a.severity)-SO.indexOf(b.severity)).map(f=><div key={f.id} className={`flex gap-2 items-start text-xs border border-blue-500/10 rounded p-2 ${f.status==="Remediated"?"opacity-50":""}`}><Badge v={f.severity}/>
      <div className="flex-1 min-w-0"><div className="text-blue-100 font-medium">{f.title}</div><div className="text-blue-300/60">{f.module} · {f.target} · {f.eng} · {f.ts}</div><div className="mt-0.5">Fix: {f.fix}</div></div>
      <button className={ghost} onClick={()=>toggle(f.id)}><Check size={12}/>{f.status==="Open"?"Remediate":"Reopen"}</button></div>)}</div>}</Card>}

function Report({s}:any){const [en,sen]=useState("");const L:F[]=s.f.filter((f:F)=>!en||f.eng===en).sort((a:F,b:F)=>SO.indexOf(a.severity)-SO.indexOf(b.severity));
  const cnt=SO.map(x=>[x,L.filter(f=>f.severity===x).length]);const open=L.filter(f=>f.status==="Open").length;
  const md=`# FX1 SHADOWCORE Report — ${en||"All engagements"}\nGenerated ${now()} UTC\n\n## Summary\n- Total findings: ${L.length} (open ${open}, remediated ${L.length-open})\n- ${cnt.map(([a,b])=>`${a}: ${b}`).join(" | ")}\n\n## Findings\n| Severity | Module | Target | Title | Status |\n|---|---|---|---|---|\n${L.map(f=>`| ${f.severity} | ${f.module} | ${f.target} | ${f.title} | ${f.status} |`).join("\n")}\n\n## Remediation\n${L.map(f=>`- **${f.title}** (${f.severity}): ${f.fix}`).join("\n")}\n`;
  return <div className="space-y-3"><div className="flex gap-2 flex-wrap np"><select className="rounded bg-[#070b14] border border-blue-500/20 px-2 py-1 text-xs" value={en} onChange={e=>sen(e.target.value)}><option value="">All engagements</option>{s.eng.map((e:any)=><option key={e.id}>{e.name}</option>)}</select>
    <button className={ghost} onClick={()=>dl("report.md",md)}><Download size={12}/>Markdown</button><button className={ghost} onClick={()=>dl("report.json",JSON.stringify({generated:now(),findings:L},null,2))}><Download size={12}/>JSON</button><button className={ghost} onClick={()=>cp(md)}><Copy size={12}/>Copy</button><button className={ghost} onClick={()=>window.print()}><Printer size={12}/>Print</button></div>
    <div className="rep rounded-lg border border-blue-500/15 bg-[#0b1220] p-4 space-y-4"><div><h2 className="text-lg font-bold text-white">FX1 SHADOWCORE — Security Assessment Report</h2><p className="text-xs text-blue-300/60">{en||"All engagements"} · {now()} UTC · Authorized testing only</p></div>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">{cnt.map(([a,b])=><div key={a as string} className="border border-blue-500/15 rounded p-2 text-center"><div className="text-xl font-bold text-white">{b}</div><Badge v={a as string}/></div>)}</div>
      {!L.length?<Empty t="No findings to report yet."/>:<><Table cols={[["severity","Severity"],["module","Module"],["target","Target"],["title","Title"],["status","Status"]]} rows={L}/><div><h3 className="text-sm font-semibold text-blue-100 mb-1">Remediation</h3><ul className="list-disc pl-4 text-xs space-y-1">{L.map(f=><li key={f.id}><b>{f.title}</b>: {f.fix}</li>)}</ul></div></>}</div></div>}

const COMMON=["password","123456","qwerty","letmein","admin","welcome","iloveyou","monkey","dragon","football"];
function Pass(){const [p,sp]=useState("");
  const ck:[string,boolean][]=[["12+ characters",p.length>=12],["Uppercase letter",/[A-Z]/.test(p)],["Lowercase letter",/[a-z]/.test(p)],["Digit",/\d/.test(p)],["Symbol",/[^a-zA-Z0-9]/.test(p)],["No repeated runs (aaa)",!/(.)\1{2,}/.test(p)],["No common words or sequences",!COMMON.some(c=>p.toLowerCase().includes(c))&&!/(0123|1234|2345|abcd|qwer|asdf)/i.test(p)]];
  let pool=0;if(/[a-z]/.test(p))pool+=26;if(/[A-Z]/.test(p))pool+=26;if(/\d/.test(p))pool+=10;if(/[^a-zA-Z0-9]/.test(p))pool+=33;
  let bits=p.length*Math.log2(pool||1);if(/(.)\1{2,}/.test(p))bits-=10;if(/(0123|1234|2345|abcd|qwer|asdf)/i.test(p))bits-=12;if(COMMON.some(c=>p.toLowerCase().includes(c)))bits-=25;bits=Math.max(0,bits);
  const lv=bits<28?0:bits<36?1:bits<60?2:bits<80?3:4;const L=["Very weak","Weak","Fair","Strong","Very strong"],C=["bg-red-500","bg-orange-500","bg-yellow-500","bg-blue-400","bg-emerald-500"];
  return <Card title="Password Strength Auditor" cls="max-w-xl"><p className="text-xs text-blue-300/60 mb-2">Analysis runs entirely in your browser. Nothing is sent or stored.</p><input type="password" className={inp} placeholder="Type a password to audit" value={p} onChange={e=>sp(e.target.value)} autoComplete="off"/>
    {!p?<div className="mt-3"><Empty t="Enter a password to see its strength."/></div>:<div className="mt-3 space-y-3"><div><div className="h-2 rounded bg-blue-950 overflow-hidden"><div className={`h-full ${C[lv]}`} style={{width:`${(lv+1)*20}%`}}/></div><div className="text-xs mt-1">{L[lv]} · ~{Math.round(bits)} bits entropy</div></div>
      <ul className="grid sm:grid-cols-2 gap-1 text-xs">{ck.map(([n,ok])=><li key={n} className={ok?"text-emerald-300":"text-blue-300/50"}>{ok?"✓":"○"} {n}</li>)}</ul></div>}</Card>}

const NAV=[["home","Command Center",LayoutDashboard],["scope","Scope & Authorization",Target],["email","Email Intelligence",Mail],["discover","Email Extractor",Search],["scan","Network Discovery",Network],["web","Web & API Analyzer",Globe],["findings","Findings Tracker",ListChecks],["report","Report Generator",FileText],["pass","Password Auditor",KeyRound]] as const;
const CFG:any={
  discover:{name:"Email Extractor",path:"/api/discover",key:"domain",ph:"example.com",btn:"Discover emails",help:"Passive discovery limited to the authorized domain: its public pages, security.txt and DNS contact.",cols:[["email","Email"],["source","Source"],["confidence","Confidence"]]},
  scan:{name:"Network Discovery",path:"/api/scan",key:"host",ph:"example.com or public IP",btn:"Scan common ports",help:"TCP connect check of ~20 well-known ports. Private/internal addresses are blocked.",cols:[["port","Port"],["service","Service"],["severity","Risk"],["note","Guidance"]]},
  web:{name:"Web & API Analyzer",path:"/api/web",key:"url",ph:"https://example.com",btn:"Analyze",help:"Single request: security headers, cookie flags, CORS and banner disclosure.",cols:[["severity","Severity"],["title","Issue"],["detail","Detail"],["fix","Remediation"]]}};

export default function App(){
  const [s,S]=useState<St>(init);const [ready,sr]=useState(false);const [v,sv]=useState("home");const [toast,st]=useState("");
  useEffect(()=>{try{const x=sessionStorage.getItem("fx1");if(x)S(JSON.parse(x))}catch{}sr(true)},[]);
  useEffect(()=>{if(ready)try{sessionStorage.setItem("fx1",JSON.stringify(s))}catch{}},[s,ready]);
  tf=(m:string)=>{st(m);setTimeout(()=>st(""),2600)};
  const add=(m:string,t:string,fs:any[])=>S(p=>({...p,jobs:[{id:uid(),m,t,ts:now()},...p.jobs].slice(0,50),f:[...fs.map(x=>({id:uid(),module:m,target:t,title:x.title,severity:x.severity,detail:x.detail||"",fix:x.fix||"",eng:p.active||"Unassigned",status:"Open" as const,ts:now()})),...p.f]}));
  const open=s.f.filter(f=>f.status==="Open");const title=NAV.find(n=>n[0]===v)![1];
  const body=v==="home"?<div className="space-y-3"><div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{[["Engagements",s.eng.length],["Open findings",open.length],["Critical / High",open.filter(f=>f.severity==="Critical"||f.severity==="High").length],["Jobs run",s.jobs.length]].map(([l,n])=><Card key={l as string}><div className="text-2xl font-bold text-white">{n}</div><div className="text-xs text-blue-300/60">{l}</div></Card>)}</div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">{(["scope","email","scan","web"] as const).map(k=>{const n=NAV.find(x=>x[0]===k)!;const I=n[2];return <button key={k} onClick={()=>sv(k)} className="text-left rounded-lg border border-blue-500/15 bg-[#0b1220] p-3 hover:border-blue-400"><I size={18} className="text-blue-400 mb-1"/><div className="text-sm font-medium text-blue-100">{n[1]}</div><div className="text-xs text-blue-300/50">Quick start</div></button>})}</div>
      <Card title="Recent activity">{!s.jobs.length?<Empty t="No activity yet. Create an engagement, then run a module."/>:<ul className="text-xs space-y-1">{s.jobs.slice(0,10).map(j=><li key={j.id} className="flex justify-between border-b border-blue-500/10 py-1"><span><b className="text-blue-100">{j.m}</b> · {j.t}</span><span className="text-blue-300/50">{j.ts}</span></li>)}</ul>}</Card></div>
    :v==="scope"?<Scope s={s} S={S}/>:v==="email"?<EmailIntel s={s} S={S} add={add}/>:v==="findings"?<Findings s={s} S={S}/>:v==="report"?<Report s={s}/>:v==="pass"?<Pass/>:<Tool key={v} cfg={CFG[v]} s={s} add={add}/>;
  return <div className="h-screen flex">
    <aside className="np hidden md:flex w-56 shrink-0 flex-col border-r border-blue-500/15 bg-[#070c17] p-3"><div className="flex items-center gap-2 mb-4"><Shield className="text-blue-400"/><div><div className="text-sm font-bold text-white tracking-wide">FX1 SHADOWCORE</div><div className="text-[10px] text-blue-300/50">Security operations</div></div></div>
      <nav className="space-y-0.5 flex-1">{NAV.map(([k,l,I])=><button key={k} onClick={()=>sv(k)} className={`w-full flex items-center gap-2 rounded px-2 py-1.5 text-xs text-left ${v===k?"bg-blue-600/20 text-blue-200 border border-blue-500/30":"hover:bg-blue-500/10 border border-transparent"}`}><I size={14}/>{l}</button>)}</nav>
      <div className="space-y-2 text-xs"><input className={inp} placeholder="Operator email" value={s.user} onChange={e=>S(p=>({...p,user:e.target.value}))}/><div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-400"/>{isAdm(s.user)?<span className="text-blue-300 font-semibold">Admin session</span>:"Standard session"}</div></div></aside>
    <div className="flex-1 flex flex-col min-w-0"><header className="np border-b border-blue-500/15 bg-[#070c17] px-3 py-2 flex items-center gap-2 flex-wrap"><h1 className="text-sm font-semibold text-white mr-auto">{title}</h1>
      <select className="rounded bg-[#070b14] border border-blue-500/20 px-2 py-1 text-xs" value={s.active} onChange={e=>S(p=>({...p,active:e.target.value}))}><option value="">No engagement</option>{s.eng.map(e=><option key={e.id}>{e.name}</option>)}</select>
      <span className="rounded border border-blue-400/50 bg-blue-500/10 text-blue-200 text-[10px] font-semibold px-2 py-1">AUTHORIZED TESTING ONLY</span>
      <select className="md:hidden rounded bg-[#070b14] border border-blue-500/20 px-2 py-1 text-xs" value={v} onChange={e=>sv(e.target.value)}>{NAV.map(n=><option key={n[0]} value={n[0]}>{n[1]}</option>)}</select>
      <input className="md:hidden rounded bg-[#070b14] border border-blue-500/20 px-2 py-1 text-xs w-full" placeholder="Operator email" value={s.user} onChange={e=>S(p=>({...p,user:e.target.value}))}/></header>
      <main className="flex-1 overflow-auto p-3">{body}</main>
      <footer className="np border-t border-blue-500/15 bg-[#070c17] px-3 py-1.5 text-xs flex gap-3 items-center overflow-x-auto"><button onClick={()=>sv("findings")} className="text-blue-300 whitespace-nowrap">Findings: {open.length} open / {s.f.length} total</button>{open.slice(0,3).map(f=><span key={f.id} className="flex gap-1 items-center whitespace-nowrap"><Badge v={f.severity}/>{f.title.slice(0,40)}</span>)}</footer></div>
    {toast&&<div className="np fixed bottom-12 right-4 rounded border border-blue-400/50 bg-[#0b1630] text-blue-100 text-xs px-3 py-2 shadow-lg">{toast}</div>}</div>}
