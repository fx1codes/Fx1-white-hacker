import dns from "dns/promises";
import {gate,bad} from "@/lib/guard";
const txt=async(n:string)=>{try{return (await dns.resolveTxt(n)).map(a=>a.join(""))}catch{return []}};
export async function POST(req:Request){
  const b=await req.json(); const g=gate(b); if(g) return bad(g,403);
  const e=String(b.email||"").trim().toLowerCase();
  if(!/^[^\s@]+@([a-z0-9-]+\.)+[a-z]{2,}$/.test(e)) return bad("Enter a valid email address.");
  const d=e.split("@")[1];
  const [mx,spfs,dm]=await Promise.all([dns.resolveMx(d).catch(()=>[]),txt(d),txt("_dmarc."+d)]);
  const spf=spfs.find(t=>t.startsWith("v=spf1")); const dmarc=dm.find(t=>t.startsWith("v=DMARC1"));
  const pol=dmarc?.match(/p=(\w+)/)?.[1];
  const sels=["default","google","selector1","selector2","k1","s1","mail"];
  const dk=(await Promise.all(sels.map(async s=>(await txt(`${s}._domainkey.${d}`)).length?s:null))).filter(Boolean);
  const F:any[]=[]; const f=(severity:string,title:string,detail:string,fix:string,w:number)=>F.push({severity,title,detail,fix,w});
  if(!mx.length) f("High","Domain has no MX records","Mail cannot be delivered to this domain.","Verify the address and domain configuration.",30);
  if(!spf) f("Medium","SPF record missing","Anyone may be able to spoof this domain.","Publish an SPF TXT record listing authorized senders.",15);
  else if(/\+all/.test(spf)) f("High","SPF allows all senders (+all)","SPF provides no protection.","Replace +all with -all or ~all.",30);
  else if(/\?all/.test(spf)) f("Low","SPF is neutral (?all)","Weak enforcement.","Move to ~all or -all.",5);
  if(!dmarc) f("Medium","DMARC record missing","No policy for spoofed mail.","Publish _dmarc TXT with p=quarantine or p=reject.",15);
  else if(pol==="none") f("Low","DMARC policy is monitor-only (p=none)","Spoofed mail is not blocked.","Move to p=quarantine, then p=reject.",5);
  if(!dk.length) f("Low","No DKIM found on common selectors","Custom selectors may exist; none detected.","Confirm DKIM signing is enabled with your mail provider.",5);
  let breach:any={status:"not_configured"};
  const key=process.env.HIBP_API_KEY;
  if(key){
    try{
      const r=await fetch(`https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(e)}?truncateResponse=true`,{headers:{"hibp-api-key":key,"user-agent":"fx1-shadowcore"},signal:AbortSignal.timeout(8000)});
      if(r.status===404) breach={status:"ok",count:0,names:[]};
      else if(r.ok){const j=await r.json();breach={status:"ok",count:j.length,names:j.map((x:any)=>x.Name).slice(0,25)};
        f(j.length>3?"High":"Medium",`Address found in ${j.length} breach(es)`,breach.names.slice(0,5).join(", "),"Rotate passwords, enable MFA, use a password manager.",j.length>3?30:20);}
      else breach={status:"error",message:`HIBP returned ${r.status}`};
    }catch(x:any){breach={status:"error",message:x.message}}
  }
  const score=Math.min(100,F.reduce((a,x)=>a+x.w,0));
  const risk=score>=40?"High":score>=15?"Medium":"Low";
  return Response.json({email:e,domain:d,risk,score,mx:mx.length,
    auth:{spf:{ok:!!spf,v:spf||"Not found"},dkim:{ok:dk.length>0,v:dk.length?"Selectors: "+dk.join(", "):"Not found on common selectors"},dmarc:{ok:!!dmarc,v:dmarc?`Policy: ${pol}`:"Not found"}},
    breach,findings:F,actions:[...new Set(F.map(x=>x.fix))]});
}
