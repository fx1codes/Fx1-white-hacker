import {gate,bad,publicHost} from "@/lib/guard";
const H:[string,string,string][]=[["strict-transport-security","High","Add Strict-Transport-Security: max-age=31536000; includeSubDomains"],["content-security-policy","Medium","Define a restrictive Content-Security-Policy"],["x-frame-options","Medium","Set X-Frame-Options: DENY or CSP frame-ancestors"],["x-content-type-options","Low","Set X-Content-Type-Options: nosniff"],["referrer-policy","Low","Set Referrer-Policy: strict-origin-when-cross-origin"],["permissions-policy","Low","Set a Permissions-Policy header"]];
export async function POST(req:Request){
  const b=await req.json(); const g=gate(b); if(g) return bad(g,403);
  let u:URL; try{u=new URL(String(b.url||""))}catch{return bad("Enter a full URL, e.g. https://example.com")}
  if(!/^https?:$/.test(u.protocol)) return bad("Only http(s) URLs are supported.");
  try{await publicHost(u.hostname)}catch(e:any){return bad(e.message)}
  let r:Response; try{r=await fetch(u,{redirect:"manual",signal:AbortSignal.timeout(8000)})}catch(e:any){return bad("Could not reach target: "+e.message,502)}
  const rows:any[]=[]; const a=(severity:string,title:string,detail:string,fix:string)=>rows.push({severity,title,detail,fix});
  if(u.protocol==="http:") a("High","Site served over plain HTTP","Traffic can be intercepted.","Serve over HTTPS and redirect HTTP.");
  for(const [h,s,fx] of H) if(!r.headers.get(h)) a(s,`Missing header: ${h}`,"Header not present in response.",fx);
  for(const h of ["server","x-powered-by"]){const v=r.headers.get(h); if(v&&/\d/.test(v)) a("Low",`Version disclosure via ${h}`,v,"Remove or genericize version banners.")}
  if(r.headers.get("access-control-allow-origin")==="*") a("Medium","CORS allows any origin","Access-Control-Allow-Origin: *","Restrict CORS to trusted origins.");
  for(const c of (r.headers as any).getSetCookie?.()||[]){const n=c.split("=")[0];
    if(!/;\s*secure/i.test(c)) a("Medium",`Cookie "${n}" missing Secure`,"Cookie may be sent over HTTP.","Add the Secure attribute.");
    if(!/;\s*httponly/i.test(c)) a("Medium",`Cookie "${n}" missing HttpOnly`,"Readable by scripts (XSS impact).","Add the HttpOnly attribute.");
    if(!/;\s*samesite/i.test(c)) a("Low",`Cookie "${n}" missing SameSite`,"CSRF exposure.","Set SameSite=Lax or Strict.");}
  return Response.json({status:r.status,rows,findings:rows});
}
