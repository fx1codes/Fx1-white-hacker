import dns from "dns/promises";
import {gate,bad,publicHost} from "@/lib/guard";
// Passive, in-scope only: reads the authorized domain's own public pages, security.txt and SOA contact.
export async function POST(req:Request){
  const b=await req.json(); const g=gate(b); if(g) return bad(g,403);
  const d=String(b.domain||"").trim().toLowerCase().replace(/^https?:\/\//,"").split("/")[0];
  if(!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(d)) return bad("Enter a valid domain, e.g. example.com");
  try{await publicHost(d)}catch(e:any){return bad(e.message)}
  const found=new Map<string,{source:string;confidence:string}>();
  const re=new RegExp("[a-z0-9._%+-]+@"+d.replace(/\./g,"\\."),"gi");
  const pages:[string,string][]=[["/","Low"],["/contact","Medium"],["/about","Medium"],["/.well-known/security.txt","High"]];
  await Promise.all(pages.map(async([p,c])=>{try{
    const r=await fetch("https://"+d+p,{signal:AbortSignal.timeout(6000)});
    const t=(await r.text()).slice(0,400000);
    for(const m of t.match(re)||[]){const k=m.toLowerCase(); if(!found.has(k)) found.set(k,{source:"Page "+p,confidence:c})}
  }catch{}}));
  try{const s=await dns.resolveSoa(d);const h=s.hostmaster.replace(/\.$/,"").replace(".","@");
    if(h.endsWith("@"+d)&&!found.has(h)) found.set(h,{source:"DNS SOA contact",confidence:"High"})}catch{}
  const rows=[...found].map(([email,v])=>({email,...v}));
  const findings=rows.length?[{severity:"Info",title:`${rows.length} public email address(es) discoverable on ${d}`,detail:rows.map(r=>r.email).join(", "),fix:"Prefer contact forms or role mailboxes; ensure SPF/DMARC protect these addresses."}]:[];
  return Response.json({rows,findings});
}
