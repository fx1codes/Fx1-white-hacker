import net from "net";
import {gate,bad,publicHost} from "@/lib/guard";
const P:Record<number,[string,string,string]>={21:["FTP","High","Cleartext protocol; use SFTP"],22:["SSH","Low","Restrict by IP, key-only auth"],23:["Telnet","Critical","Disable; use SSH"],25:["SMTP","Low","Ensure no open relay"],53:["DNS","Low","Restrict recursion"],80:["HTTP","Low","Redirect to HTTPS"],110:["POP3","Medium","Use POP3S"],135:["MSRPC","High","Block at firewall"],139:["NetBIOS","High","Block at firewall"],143:["IMAP","Medium","Use IMAPS"],443:["HTTPS","Info","Verify TLS config"],445:["SMB","High","Block from internet"],1433:["MSSQL","High","Never expose DBs"],3306:["MySQL","High","Never expose DBs"],3389:["RDP","High","Use VPN/MFA gateway"],5432:["PostgreSQL","High","Never expose DBs"],5900:["VNC","High","Tunnel via VPN"],6379:["Redis","Critical","Require auth, bind privately"],8080:["HTTP-alt","Low","Review exposed admin apps"],9200:["Elasticsearch","High","Require auth, bind privately"],27017:["MongoDB","Critical","Require auth, bind privately"]};
const probe=(h:string,p:number)=>new Promise<boolean>(r=>{const s=net.connect({host:h,port:p,timeout:1500});s.on("connect",()=>{s.destroy();r(true)});s.on("timeout",()=>{s.destroy();r(false)});s.on("error",()=>r(false))});
export async function POST(req:Request){
  const b=await req.json(); const g=gate(b); if(g) return bad(g,403);
  const h=String(b.host||"").trim().toLowerCase();
  let ip:string; try{ip=await publicHost(h)}catch(e:any){return bad(e.message)}
  const res=await Promise.all(Object.keys(P).map(Number).map(async p=>(await probe(ip,p))?p:0));
  const rows=res.filter(Boolean).map(p=>({port:p,service:P[p][0],severity:P[p][1],note:P[p][2]}));
  const findings=rows.filter(r=>r.severity!=="Info").map(r=>({severity:r.severity,title:`Open port ${r.port} (${r.service}) on ${h}`,detail:"Reachable from the internet.",fix:r.note}));
  return Response.json({ip,rows,findings});
}
