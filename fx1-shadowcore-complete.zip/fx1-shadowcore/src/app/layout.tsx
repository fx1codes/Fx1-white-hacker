import "./globals.css";
export const metadata={title:"FX1 SHADOWCORE",description:"Authorized security operations platform"};
export default function L({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
